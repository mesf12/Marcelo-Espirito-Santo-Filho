﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marcelo.tarefas.MotoresP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] valor;
            valor = new double[15];
            int op;
            int motor;
            double total;
            do
            {
                Console.WriteLine("0 Sair");
                Console.WriteLine("1 Lançar valor");
                Console.WriteLine("2 Mostrar valores");
                Console.Write("Sua opção: ");
                op = int.Parse(Console.ReadLine());

                if (op == 1)
                {
                    do
                    {
                        Console.WriteLine("Qual o motor?: ");
                        motor = int.Parse(Console.ReadLine());
                    }
                    while (motor < 1 || motor > 15);

                    Console.WriteLine("Qual o valor?: ");
                    valor[motor - 1] = double.Parse(Console.ReadLine());

                    Console.WriteLine("Valor registrado:");
                }
                else
                    if (op == 2)
                {
                    total = 0;
                    for (motor = 0; motor < 15; motor++)
                    {
                        Console.WriteLine("Motor {0}: R$ {1}", motor, valor[motor]);
                        total += valor[motor];
                    }
                    Console.WriteLine("-------------");
                    Console.WriteLine("Total: R$ [0]", total);
                }
            }
            while (op != 0);
        }
    }
}
